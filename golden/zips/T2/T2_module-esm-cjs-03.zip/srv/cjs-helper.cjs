module.exports = { msg: "CJS OK" };
